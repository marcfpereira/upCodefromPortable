let x=5;
let y=4;

console.log(x+y);